﻿using System;

class Bank
{
    static void Main()
    {
        int time;
        double principle, rate, interest;
        string name;

        Console.WriteLine("please enter your name");
        name = Console.ReadLine();
        Console.WriteLine("please enter the principle");
        principle = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("please the time in years");
        time = Convert.ToInt16(Console.ReadLine());
        Console.WriteLine("please enter the rate");
        rate = Convert.ToDouble(Console.ReadLine());
        interest = principle * time * rate / 100;

        Console.WriteLine("SI = {0}", interest);
        Console.ReadLine();


        Decide:
        Console.WriteLine("Do you want to calculate CI - Yes or No?");
        string userchoice = Console.ReadLine();

        switch (userchoice)
        {
            case "Yes":
                int year;
                double amount, princ, Rate, CI;
               

                
                Console.WriteLine("please enter the principal amount");
                princ = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("please enter the Rate");
                Rate = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("please enter the Years");
                year = Convert.ToInt16(Console.ReadLine());

                amount = princ * Math.Pow(1 + Rate / 100, year);

                CI = amount - princ;

                Console.WriteLine("Compound Interest :" + CI);
                Console.ReadLine();

                break;

            case "No":
                break;

            default:
                Console.WriteLine("please enter the valid choice again...");
                goto Decide;
                
        }
        Console.WriteLine("Thankyou for using our service");
        

        
    }
}