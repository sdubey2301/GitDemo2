﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conn.Entities
{
    public class EEmployee
    {
        public int EmpID { get; set; }
        public string Name { get; set; }
        public int age { get; set; }
        public string contactno { get; set; }
        public string ValueToSearch { get; set; }
        public string Property { get; set; }
        public string EnterValue { get; set; }
    }
}
